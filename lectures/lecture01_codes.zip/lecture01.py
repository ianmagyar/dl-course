import tensorflow as tf

import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split

from keras.models import Sequential
from keras.layers import Dense
from keras.optimizers import Adam


# simple neuron with two input nodes
def my_neuron(x):
    # define some arbitrary weights for the two input values
    W = tf.Variable(tf.ones((2, 1)))

    # define the bias of the neuron
    b = tf.Variable(1, dtype=tf.float32)

    # compute weighted sum (hint: check out tf.matmul)
    z = tf.matmul(x, W) + b
    print(z)

    # apply the sigmoid activation function (hint: use tf.sigmoid)
    output = tf.sigmoid(z)

    return output


sample_input = tf.constant([[2, 3]], shape=(1, 2), dtype=tf.float32)

# if you've done everything correctly, this should give you a tensor with value 0.997
result = my_neuron(sample_input)
print(result)

# KERAS
tf.compat.v1.disable_eager_execution()
dataset = pd.read_csv("iris.csv")

X = dataset.iloc[:, :4].values
y = dataset.iloc[:, -1].values

encoder = LabelEncoder()
y1 = encoder.fit_transform(y)

Y = pd.get_dummies(y1).values

X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y, test_size=0.2)

model = Sequential()

model.add(Dense(10, input_shape=(4,), activation='tanh'))
model.add(Dense(8, activation='tanh'))
model.add(Dense(6, activation='tanh'))
model.add(Dense(3, activation='softmax'))

model.summary()
model.compile(Adam(lr=0.04), loss='categorical_crossentropy', metrics=['accuracy'])


model.fit(X_train, Y_train, epochs=100)

Y_pred = model.predict(X_test)

# testing
import numpy as np

Y_test_class = np.argmax(Y_test, axis=1)
Y_pred_class = np.argmax(Y_pred, axis=1)

from sklearn.metrics import classification_report, confusion_matrix

print(classification_report(Y_test_class, Y_pred_class))
print(confusion_matrix(Y_test_class, Y_pred_class))
